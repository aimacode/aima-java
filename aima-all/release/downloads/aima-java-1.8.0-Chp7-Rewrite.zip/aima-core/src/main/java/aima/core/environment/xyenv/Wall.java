package aima.core.environment.xyenv;

import aima.core.agent.EnvironmentObject;

/**
 * @author Ravi Mohan
 * 
 */
public class Wall implements EnvironmentObject {

}