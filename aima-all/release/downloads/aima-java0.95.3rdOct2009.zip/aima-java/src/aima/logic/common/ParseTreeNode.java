/*
 * Created on Sep 14, 2003 by Ravi Mohan
 *  
 */
package aima.logic.common;

/**
 * @author Ravi Mohan
 * 
 */

public interface ParseTreeNode {

}