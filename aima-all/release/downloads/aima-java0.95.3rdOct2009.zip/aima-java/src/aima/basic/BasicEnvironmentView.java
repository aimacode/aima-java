package aima.basic;

/**
 * @author Ravi Mohan
 * 
 */
public class BasicEnvironmentView {

	public void envChanged(String command) {
		System.out.println(command);

	}

}