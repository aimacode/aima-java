/*
 * Created on Aug 5, 2005
 *
 */
package aima.learning.framework;

/**
 * @author Ravi Mohan
 * 
 */
public interface Attribute {
	public String valueAsString();

	public String name();

}
